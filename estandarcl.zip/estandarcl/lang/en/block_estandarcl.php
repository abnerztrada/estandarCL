<?php
$string['estandarcl'] = 'Personalizado block';
$string['estandarcl'] = 'Personalizado';
$string['estandarcl:addinstance'] = 'Add a new Personalizado block';
$string['estandarcl:myaddinstance'] = 'Add a new Personalizado block to the My Moodle page';
$string['blocksettings'] = 'Block settings';
$string['blockstring'] = 'Block string';
$string['blocktitle'] = 'Title';
$string['blockfooter'] = 'Footer';
$string['headerconfig'] = 'Header config';
$string['descconfig'] = 'Desc config';
$string['labelallowhtml'] = 'Label allow html';
$string['descallowhtml'] = 'Desc allow html';
$string['textfields'] = 'Mi Tablero Personalizado';
$string['edithtml'] = 'Mi Tablero Personalizado';
$string['estandarclsetting'] = 'Ajustes estandarcl';
$string['editpage'] = 'Editar pagina';

$string['rangoadmin'] = 'Rango de fecha';
$string['rangoestudiante'] = 'Rango de Fecha';

$string['empresa'] = 'Empresa';
$string['codigo'] = 'Código';
$string['curso'] = 'Curso';
