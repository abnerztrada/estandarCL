<?php
// namespace block_estandarcl\libs;
// $nombre = "Abcd1234";
// echo preg_match("/[A-Z]+[a-z]+[0-9]+[\!\.\(\)\?\-\_\#\$]+/",$nombre);
class Validate{
     protected $npass;
     public function __construct(){

     }
     public function verifyPass($pass){
          $this->npass = preg_match("/[A-Z]+[a-z]+[0-9]+[\!\.\(\)\?\-\_\#\$\&]+/",$pass);
          if($this->npass == 1){
               return $pass;
          }
          else{
               return "password invalido";
          }

     }
     public function verifyMail($str){
          return (false !== filter_var($str, FILTER_VALIDATE_EMAIL));
     }
}

// way to use
// $password = "Abcd1234!";
// $mail  = "irunga1@yahoo.com";
// $obj  = new Validate();
// echo $obj->verifyPass($password);
// echo "<hr>";
// echo $obj->verifyMail($mail);

?>
