<?php
require_once('../../../config.php');
/**
 *
 */
class Apimodel
{

  function __construct()
  {
    global $DB;
    $this->global = $DB;
  }

  public function verificarUsuario($email){
    global $DB,$USER;
    $query = "SELECT @s:=@s + 1 id_auto, mu.* FROM (select @s:=0) as s, mdl_user mu where mu.email = '$email'";
    return $DB->get_records_sql($query);
  }
}


?>
