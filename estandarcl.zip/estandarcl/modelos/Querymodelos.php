<?php
//Incluímos inicialmente la conexión a la base de datos
require_once('../../../config.php');
Class Consultas
{
	 protected $global;

    //Implementamos nuestro constructor
    public function __construct()
    {
       global $DB;
        $this->global = $DB;
    }
//Datos generales
public function reportegeneral($inicio,$fin,$codigo,$curso,$empresa)
	{
		global $DB,$USER;

      $data = $DB->get_records_sql("SELECT   @s:=@s+1 id,Concat(u.firstname,' ',u.lastname) as nombre,
																u.id as codigo,
																c.fullname as curso,
																empresa.data as empresa,
															  DATE_FORMAT(DATE_ADD(FROM_UNIXTIME(c.startdate ,'%Y-%m-%d %h:%i'),INTERVAL 7 HOUR),'%d/%m/%Y %H:%i')as inicio,
																DATE_FORMAT(DATE_ADD(FROM_UNIXTIME(c.enddate ,'%Y-%m-%d %h:%i'),INTERVAL 7 HOUR),'%d/%m/%Y %H:%i')as final,
																DATE_FORMAT(DATE_ADD(FROM_UNIXTIME(cc.timecompleted ,'%Y-%m-%d %h:%i'),INTERVAL 7 HOUR),'%d/%m/%Y %H:%i')as completado,
																			CASE When
																		    	notas.finalgrade<=0 or notas.finalgrade is null
																		      THEN
																		        '0'
																				 ELSE
																		   	notas.finalgrade
																			END AS nota,
																		CASE when compl.num<=0 or compl.num is null THEN '0%'
																		ELSE concat(cast(((compl.num*100)/act.num)as decimal(16,0)),'%')
																		END AS avance
																		from (SELECT @s:= 0) AS s,mdl_user u
																		inner join (Select distinct ue.userid, e.courseid,ue.timestart from mdl_user_enrolments ue
																		inner join mdl_enrol e
																		on ue.enrolid=e.id
																		) as usrcourse
																		on u.id=usrcourse.userid
																		inner join (Select userid,data from mdl_user_info_data d
																						inner join mdl_user_info_field c
																						on d.fieldid=c.id
																		where c.shortname ='empresa' and data <> '') as empresa
																		on empresa.userid=u.id
																		left join (Select gi.courseid,gg.userid,gg.finalgrade
																		from mdl_grade_items gi
																		inner join mdl_grade_grades gg
																		on gg.itemid=gi.id
																		where gi.itemtype='course')as notas
																		on u.id=notas.userid and usrcourse.courseid=notas.courseid
																		left join mdl_course_completions cc
																		on u.id=cc.userid and usrcourse.courseid=cc.course
																		left join(Select count(id)as num,course from mdl_course_completion_criteria
																		group by course) as act
																		on act.course=usrcourse.courseid
																		left join (Select userid,course,count(id)as num from mdl_course_completion_crit_compl
																		group by course, userid)as compl
																		on compl.userid=u.id and compl.course=usrcourse.courseid
																		left join mdl_course c
																		on usrcourse.courseid = c.id
																		where
																		 u.deleted=0
																		 and u.suspended=0
																		 and u.id = $USER->id
																		 and u.id like '%".$codigo."%'
																		 and empresa.data like '%".$empresa."%'
																		 and c.shortname like '%".$curso."%'
																		 and usrcourse.timestart>='".$inicio."'
																		 and usrcourse.timestart<='".$fin."'"
				 												 	);
						return $data;
		}


		public function reportegeneral2($inicio,$fin,$codigo,$curso,$empresa)
			{

				global $DB,$USER;

				  $data = $DB->get_records_sql("SELECT   @s:=@s+1 id,Concat(u.firstname,' ',u.lastname) as nombre,
																		u.id as codigo,
																		c.fullname as curso,
																		empresa.data as empresa,
																	  DATE_FORMAT(DATE_ADD(FROM_UNIXTIME(c.startdate ,'%Y-%m-%d %h:%i'),INTERVAL 7 HOUR),'%d/%m/%Y %H:%i')as inicio,
																		DATE_FORMAT(DATE_ADD(FROM_UNIXTIME(c.enddate ,'%Y-%m-%d %h:%i'),INTERVAL 7 HOUR),'%d/%m/%Y %H:%i')as final,
																		DATE_FORMAT(DATE_ADD(FROM_UNIXTIME(cc.timecompleted ,'%Y-%m-%d %h:%i'),INTERVAL 7 HOUR),'%d/%m/%Y %H:%i')as completado,
																					CASE When
																				    	notas.finalgrade<=0 or notas.finalgrade is null
																				      THEN
																				        '0'
																						 ELSE
																				   	notas.finalgrade
																					END AS nota,
																				CASE when compl.num<=0 or compl.num is null THEN '0%'
																				ELSE concat(cast(((compl.num*100)/act.num)as decimal(16,0)),'%')
																				END AS avance
																				from (SELECT @s:= 0) AS s,mdl_user u
																				inner join (Select distinct ue.userid, e.courseid,ue.timestart from mdl_user_enrolments ue
																				inner join mdl_enrol e
																				on ue.enrolid=e.id
																				) as usrcourse
																				on u.id=usrcourse.userid
																				LEFT join (Select userid,data from mdl_user_info_data d
												                        inner join mdl_user_info_field c
												                        on d.fieldid=c.id
												                where c.shortname ='empresa' and data <> '') as empresa
												                on empresa.userid=u.id
																				left join (Select gi.courseid,gg.userid,gg.finalgrade
																				from mdl_grade_items gi
																				inner join mdl_grade_grades gg
																				on gg.itemid=gi.id
																				where gi.itemtype='course')as notas
																				on u.id=notas.userid and usrcourse.courseid=notas.courseid
																				left join mdl_course_completions cc
																				on u.id=cc.userid and usrcourse.courseid=cc.course
																				left join(Select count(id)as num,course from mdl_course_completion_criteria
																				group by course) as act
																				on act.course=usrcourse.courseid
																				left join (Select userid,course,count(id)as num from mdl_course_completion_crit_compl
																				group by course, userid)as compl
																				on compl.userid=u.id and compl.course=usrcourse.courseid
																				left join mdl_course c
																				on usrcourse.courseid = c.id
																				where
																				 u.deleted=0
																				 and u.suspended=0
																				 and u.id like '%".$codigo."%'
																				 and empresa.data like '%".$empresa."%'
																				 and c.shortname like '%".$curso."%'
																				 and usrcourse.timestart>='".$inicio."'
																				 and usrcourse.timestart<='".$fin."'"
						 												 	);
								return $data;

				}

public function getRol($id){
	 global $DB;
	 $query = "";
 	 $query .= " SELECT  distinct r.shortname as rol FROM";
 	 $query .= " (select @s:=0) as s,";
 	 $query .= " mdl_user u";
 	 $query .= " INNER JOIN mdl_role_assignments as asg on asg.userid = u.id";
 	 $query .= " INNER JOIN mdl_context as con on asg.contextid = con.id";
 	 $query .= " INNER JOIN mdl_course c on con.instanceid = c.id";
 	 $query .= " INNER JOIN mdl_role r on asg.roleid = r.id";
 	 $query .= " where  u.id = $id";
 	 return $DB->get_records_sql($query);
}

public function cursos(){
				global $DB,$USER;

         		 $data = $DB->get_records_sql("SELECT distinct(shortname),id from mdl_course
											   where shortname is not null  and id<>1 or shortname=''");
						return $data;
}


public function areas(){
				global $DB,$USER;

         		 $data = $DB->get_records_sql("SELECT distinct(empresa.data)as empresa
		         		 								from mdl_user u left join
									         		 	(Select userid,data
									         		 	from mdl_user_info_data d
									         		 	inner join mdl_user_info_field c on d.fieldid=c.id
									         		 	where c.shortname ='empresa')
									         		 	as empresa on empresa.userid=u.id where empresa.data <>''");
						return $data;
			}

public function areas2(){
				global $DB,$USER;

         		 $data = $DB->get_records_sql("SELECT distinct(empresa.data)as empresa
		         		 								from mdl_user u left join
									         		 	(Select userid,data
									         		 	from mdl_user_info_data d
									         		 	inner join mdl_user_info_field c on d.fieldid=c.id
									         		 	where c.shortname ='empresa' and d.userid = $USER->id)
									         		 	as empresa on empresa.userid=u.id where empresa.data <>''");
						return $data;
			}

}

?>
