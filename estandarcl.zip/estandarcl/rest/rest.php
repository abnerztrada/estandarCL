<?php

require_once('../../../config.php');
require_once("{$CFG->libdir}/tablelib.php");
require_once("../modelos/Apimodel.php");
require_once("../libs/Validate.php");
require_once("../../../lib/authlib.php");

global $DB, $OUTPUT, $USER, $PAGE;
$context=context_system::instance();
$download = optional_param('download', '', PARAM_ALPHA);
$PAGE->set_context($context);
$PAGE->set_url($CFG->wwwroot.'/blocks/estandarcl/rest/rest.php');
$viewURL= new moodle_url($CFG->wwwroot.'/blocks/estandarcl/rest/rest.php');

// user_update_password
// echo $USER->email;


if(isset($_GET)){
       $nombre =  $_GET['nombre'];
       $correo = $_GET['email'];
       $passw = $_GET["password"];
       $usuario = null;
       $obj2 = new Apimodel();
       $usuario = $obj2->verificarUsuario($correo);
       // echo '<pre>';
       // print_r($usuario);
       // echo '</pre>';

       $usuario = $usuario[1];
       // echo '<pre>';
       // print_r($usuario);
       // echo '</pre>';

       // $password = "Abcd1234!";
       // $mail  = "irunga1@yahoo.com";
       $obj  = new Validate();
       $nuevopass = $obj->verifyPass($passw);
       $valemail =  $obj->verifyMail($correo);

       if($nuevopass !="password invalido" || $valemail == 1 ){
         $array =  array(
              "nombre" =>$nombre,
              "email" =>$correo,
              "password"=>$passw
         );
         if($usuario != null || $usuario->email != null  ||  $usuario->email != ''){

           // $user = user_update_password($usuario->id, $passw);
           // $update = array(
           //   "id"=>$array["id"],
           //   "email"=>$array["email"],
           //   "password"=>md5($array["password"])
           // );
           // $update= (object) $update;
           $usuario->password = md5($array["password"]);
           // echo '<pre>';
           // print_r($update);
           // echo '</pre>';
           $resultado = $DB->update_record('user',$usuario, $bulk= false);
           $array = json_encode($array);
           header('Content-Type: application/json');
           echo $array;

         }
       }
}


?>
