<?php
require_once("{$CFG->libdir}/formslib.php");
require_once('../modelos/Querymodelos.php');
class administrador extends moodleform {

    function definition() {
      global $USER, $DB;


$reporte1 = new Consultas();

//Consultas a la base de datos
$getRola = new Consultas();
$alum = $getRola->getRol($USER->id);
$rol = $alum["student"]->rol;
$rol2 = $alum["directorrrhh"]->rol;
$rol3 = $alum["directorrrhh"]->rol;
$nombre = $USER->id;
// echo $nombre;

$admin = is_siteadmin();

// echo '<pre>';
//   print_r($rol);
// echo '</pre>';

$cursosinfo=$reporte1->cursos();
$areainfo=$reporte1->areas();
$areainfo2=$reporte1->areas2();

$arraycurso['seleccionacurso']='Selecciona tu curso';
$arrayarea['seleccionaarea']='Selecciona tu region';

$getRola = new Consultas();
foreach ($cursosinfo as $key => $value) {
  $arraycurso[$key] = $value->shortname;
}

// foreach ($areainfo as $key => $value) {
//     $arrayarea[$key] = $value->empresa;
//   }
//
// foreach ($areainfo2 as $key => $value) {
//     $arrayarea[$key] = $value->empresa;
// }

if($rol == 'student' && $admin != 1){
  foreach ($areainfo2 as $key => $value) {
    $arrayarea[$key] = $value->empresa;
  }
}else if ($rol3 == 'editingteacher' && $admin != 1 ){
  foreach ($areainfo2 as $key => $value) {
    $arrayarea[$key] = $value->empresa;
  }
}else if($rol2 == 'directorrrhh' && $admin != 1){
  foreach ($areainfo2 as $key => $value) {
    $arrayarea[$key] = $value->empresa;
  }
}else if ($admin = 1) {
  foreach ($areainfo as $key => $value) {
    $arrayarea[$key] = $value->empresa;
  }
}

// $inicio=strtotime($fecha_inicio);
// $fecha_inicio=$_REQUEST["fecha_inicio"."-3 month"];


        $mform =& $this->_form;
        $mform->addElement('header','displayinfo', get_string('textfields', 'block_estandarcl'));
     	  $mform->addElement('date_selector', 'fecha_inicio', get_string('from'));
      	$mform->addElement('date_selector', 'fecha_fin', get_string('to'));
        $mform->addElement('select', 'curso', get_string('curso', 'block_estandarcl'), $arraycurso);
        $mform->addElement('select', 'empresa', get_string('empresa', 'block_estandarcl'), $arrayarea);
        $mform-> addElement ('text', 'codigo', get_string ('codigo', 'block_estandarcl'));





}

}







?>
