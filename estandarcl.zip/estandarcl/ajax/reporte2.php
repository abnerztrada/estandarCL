<?php

require_once "../modelos/Querymodelos.php";
//llamado  a la base de datos
$reporte2 = new Consultas();
//Variables a utilizar
$fecha_inicio=$_REQUEST["fecha_inicio"];
$fecha_fin=$_REQUEST["fecha_fin"];
//Trasformacion de fecha
$inicio=strtotime($fecha_inicio);
$fin=strtotime($fecha_fin);
$codigo=$_REQUEST["codigo"];
$curso=$_REQUEST["curso"];
$empresa=$_REQUEST["empresa"];

if($curso=='seleccionacurso'){
  $curso="";
}
if($empresa=='seleccionaarea'){
  $empresa="";
}



$rspta=$reporte2->reportegeneral2($inicio,$fin,$codigo,$curso,$empresa);
        $data= Array();

          foreach ($rspta as $key => $valor) {
              $data[]=array(
                "0"=>$valor->id,
                "1"=>$valor->nombre,
                "2"=>$valor->codigo,
                "3"=>$valor->empresa,
                "4"=>$valor->curso,
                "5"=>$valor->inicio,
                "6"=>$valor->final,
                "7"=>$valor->avance,
                "8"=>$valor->nota,
                "9"=>$valor->completado

                            );
              }

        $results = array(
            "sEcho"=>1, //Información para el datatables
            "iTotalRecords"=>count($data), //enviamos el total registros al datatable
            "iTotalDisplayRecords"=>count($data), //enviamos el total registros a visualizar
            "aaData"=>$data);
        echo json_encode($results);

  exit;
